{{/*
Common labels
*/}}
{{- define "labels.common" -}}
app: {{ include "name" . | quote }}
{{ include "labels.selector" . }}
application.giantswarm.io/branch: {{ .Values.project.branch | quote }}
application.giantswarm.io/commit: {{ .Values.project.commit | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end }}

{{- define "labels.backstage" }}
{{- if (.Values.backstageDiscovery).kubernetesId }}
backstage.io/kubernetes-id: {{ .Values.backstageDiscovery.kubernetesId }}
{{- end }}
{{- end }}

{{/*
Cilium DNS egress rule (kube-dns / coredns / node-local cache in kube-system on
53 and 1053). Rendered as a YAML list item; the caller provides the surrounding
`egress:` key. The k8s-app label of the cluster DNS pods differs by cluster, so
all three known values are matched.
*/}}
{{- define "backstage.dnsEgress" -}}
- toEndpoints:
    - matchLabels:
        io.kubernetes.pod.namespace: kube-system
        k8s-app: kube-dns
    - matchLabels:
        io.kubernetes.pod.namespace: kube-system
        k8s-app: coredns
    - matchLabels:
        io.kubernetes.pod.namespace: kube-system
        k8s-app: k8s-dns-node-cache
  toPorts:
    - ports:
        - port: "1053"
          protocol: UDP
        - port: "1053"
          protocol: TCP
        - port: "53"
          protocol: UDP
        - port: "53"
          protocol: TCP
{{- end -}}

{{/*
Kubernetes NetworkPolicy DNS egress rule, the kubernetes flavor of
backstage.dnsEgress. Rendered as a YAML list item; the caller provides the
surrounding `egress:` key.
*/}}
{{- define "backstage.dnsEgress.kubernetes" -}}
- to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: kube-system
      podSelector:
        matchExpressions:
          - key: k8s-app
            operator: In
            values: [kube-dns, coredns, k8s-dns-node-cache]
  ports:
    - port: 53
      protocol: UDP
    - port: 53
      protocol: TCP
    - port: 1053
      protocol: UDP
    - port: 1053
      protocol: TCP
{{- end -}}
