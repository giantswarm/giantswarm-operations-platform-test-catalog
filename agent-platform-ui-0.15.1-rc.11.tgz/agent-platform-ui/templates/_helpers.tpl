{{- /*
Validate slug at render time. Fail fast with a clear message rather than producing
a broken manifest that surfaces an error later in Flux reconcile.
*/ -}}

{{- define "agent-platform-ui.validate" -}}
{{- $slug := .Values.slug | default "" -}}
{{- if not (regexMatch "^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$" $slug) -}}
{{- fail (printf "values.slug %q does not match ^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$" $slug) -}}
{{- end -}}
{{- end -}}

{{- /*
The release name. The Helm release is named externally (by the fleet HelmRelease),
but we provide a deterministic resource name here so that all resources within a
release agree on what to call the workload.
*/ -}}
{{- define "agent-platform-ui.fullname" -}}
{{- printf "prototype-%s" .Values.slug | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "agent-platform-ui.labels" -}}
app.kubernetes.io/name: agent-platform-ui
app.kubernetes.io/instance: {{ include "agent-platform-ui.fullname" . }}
app.kubernetes.io/managed-by: helm
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
agent-platform-ui/slug: {{ .Values.slug | quote }}
{{- end -}}

{{- define "agent-platform-ui.selectorLabels" -}}
app.kubernetes.io/name: agent-platform-ui
app.kubernetes.io/instance: {{ include "agent-platform-ui.fullname" . }}
{{- end -}}

{{- /*
Image reference. Registry and repo are hardcoded so that a compromised fleet bot
cannot redirect the deployment to an arbitrary image.

The image tag is derived from `.Chart.AppVersion`, not `.Chart.Version`. Flux's
source-controller appends the 12-char OCI artifact digest to `.Chart.Version`
as semver build metadata (e.g. `0.0.2+7fcf73b510eb`), which isn't a valid
Docker tag. AppVersion isn't touched by Flux. The architect orb stamps both
fields with the same gitsemver value at build time (since this repo has no
`pkg/project/project.go`), so chart and image co-version off AppVersion.

The `trimPrefix "0.0.0-"` accounts for future per-branch builds where the
chart is packaged as `0.0.0-branch-<slug>-<build-num>` but the image is
tagged `branch-<slug>-<build-num>` (registry tags aren't required to be semver).
*/ -}}
{{- define "agent-platform-ui.image" -}}
gsociprivate.azurecr.io/giantswarm/agent-platform-ui:{{ trimPrefix "0.0.0-" .Chart.AppVersion }}
{{- end -}}

{{- /*
SitePing feedback backend. A separate workload from the static-file app, named
`<fullname>-siteping`. Its `app.kubernetes.io/name` is deliberately distinct
(`agent-platform-ui-siteping`) so the app Service/NetworkPolicy selectors —
which match `name=agent-platform-ui` — never accidentally target these pods.
*/ -}}
{{- define "agent-platform-ui.siteping.fullname" -}}
{{- printf "%s-siteping" (include "agent-platform-ui.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "agent-platform-ui.siteping.selectorLabels" -}}
app.kubernetes.io/name: agent-platform-ui-siteping
app.kubernetes.io/instance: {{ include "agent-platform-ui.fullname" . }}
{{- end -}}

{{- define "agent-platform-ui.siteping.labels" -}}
{{ include "agent-platform-ui.siteping.selectorLabels" . }}
app.kubernetes.io/managed-by: helm
app.kubernetes.io/component: siteping
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
agent-platform-ui/slug: {{ .Values.slug | quote }}
{{- end -}}

{{- /*
SitePing backend image. Unlike the app image this lives in the PUBLIC
gsoci.azurecr.io registry (the backend contains nothing private), so the chart
pulls it without an imagePullSecret. Registry/repo are hardcoded for the same
supply-chain reason as the app image; the tag co-versions off AppVersion.
*/ -}}
{{- define "agent-platform-ui.siteping.image" -}}
gsoci.azurecr.io/giantswarm/siteping-backend:{{ trimPrefix "0.0.0-" .Chart.AppVersion }}
{{- end -}}

{{/*
Pod scheduling constraints: renders the `nodeSelector` and `tolerations` fields,
merging the `architecture` shorthand into the explicit values for both.

Giant Swarm arm64 node pools carry a `kubernetes.io/arch=arm64:NoSchedule`
taint, so a pod bound to arm64 needs the node selector *and* the matching
toleration: with only the selector it stays Pending, with only the toleration
it may be scheduled onto any pool.

The toleration is therefore derived from the *effective* `kubernetes.io/arch`
selector, whichever of the two values set it, so pinning through `nodeSelector`
alone is as safe as pinning through `architecture`. It is skipped when an
explicit toleration already covers that taint, matching on the fields that
decide coverage rather than on the whole dict.

A `nodeSelector` that sets `kubernetes.io/arch` to something other than
`architecture` is a contradiction rather than a preference to arbitrate, so it
fails the render instead of silently discarding one of the two.
Emits nothing when unset, so rendered output is unchanged for existing users.
*/}}
{{- define "agent-platform-ui.podScheduling" -}}
{{- $nodeSelector := deepCopy (.Values.nodeSelector | default dict) -}}
{{- $tolerations := .Values.tolerations | default list -}}
{{- with .Values.architecture -}}
{{- if and (hasKey $nodeSelector "kubernetes.io/arch") (ne (index $nodeSelector "kubernetes.io/arch") .) -}}
{{- fail (printf "architecture=%s conflicts with nodeSelector.%q=%s; set only one" . "kubernetes.io/arch" (index $nodeSelector "kubernetes.io/arch")) -}}
{{- end -}}
{{- $nodeSelector = merge (dict "kubernetes.io/arch" .) $nodeSelector -}}
{{- end -}}
{{- if eq (index $nodeSelector "kubernetes.io/arch" | default "") "arm64" -}}
{{- $tolerated := false -}}
{{- range $tolerations -}}
{{- if and (eq (.key | default "") "kubernetes.io/arch") (has (.effect | default "") (list "" "NoSchedule")) -}}
{{- if or (eq (.operator | default "Equal") "Exists") (eq (.value | default "") "arm64") -}}
{{- $tolerated = true -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if not $tolerated -}}
{{- $tolerations = concat $tolerations (list (dict "key" "kubernetes.io/arch" "operator" "Equal" "value" "arm64" "effect" "NoSchedule")) -}}
{{- end -}}
{{- end -}}
{{- $scheduling := dict -}}
{{- if $nodeSelector -}}{{- $_ := set $scheduling "nodeSelector" $nodeSelector -}}{{- end -}}
{{- if $tolerations -}}{{- $_ := set $scheduling "tolerations" $tolerations -}}{{- end -}}
{{- with $scheduling }}{{ toYaml . }}{{ end -}}
{{- end -}}
