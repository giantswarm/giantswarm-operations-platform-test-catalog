# web-assets-app

Static files used on potentially multiple web sites

**Homepage:** <https://github.com/giantswarm/web-assets>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| name | string | `"web-assets-app"` |  |
| namespace | string | `"giantswarmio"` |  |
| image.registry | string | `"gsoci.azurecr.io"` |  |
| image.name | string | `"giantswarm/web-assets"` |  |
| resources.requests.cpu | string | `"5m"` |  |
| resources.requests.memory | string | `"5Mi"` |  |
| resources.requests.ephemeralStorage | string | `"50Mi"` |  |
| resources.limits.cpu | string | `"100m"` |  |
| resources.limits.memory | string | `"30Mi"` |  |
| resources.limits.ephemeralStorage | string | `"200Mi"` |  |
| route | object | `{"additionalRules":[],"annotations":{},"enabled":false,"filters":[],"hostnames":[],"kind":"HTTPRoute","labels":{},"matches":[{"path":{"type":"PathPrefix","value":"/"}}],"name":"","parentRefs":[],"securityPolicy":{"annotations":{},"enabled":false,"labels":{}}}` | Gateway API Route configuration |
| route.enabled | bool | `false` | Enable Gateway API HTTPRoute |
| route.kind | string | `"HTTPRoute"` | Set the route kind Valid options are GRPCRoute, HTTPRoute, TCPRoute, TLSRoute, UDPRoute |
| route.name | string | `""` | Override the route name (defaults to .Values.name) |
| route.annotations | object | `{}` | Additional annotations to add to the route |
| route.labels | object | `{}` | Additional labels to add to the route |
| route.hostnames | list | `[]` | Hostnames for the route |
| route.parentRefs | list | `[]` | Parent references (Gateway) for the route |
| route.matches | list | `[{"path":{"type":"PathPrefix","value":"/"}}]` | Matching rules for the route |
| route.filters | list | `[]` | Filters to apply to requests matching this rule |
| route.additionalRules | list | `[]` | Additional custom rules that can be added to the route |
| route.securityPolicy | object | `{"annotations":{},"enabled":false,"labels":{}}` | Envoy Gateway SecurityPolicy configuration |
| route.securityPolicy.enabled | bool | `false` | Enable SecurityPolicy for the route |
| route.securityPolicy.annotations | object | `{}` | Additional annotations for SecurityPolicy |
| route.securityPolicy.labels | object | `{}` | Additional labels for SecurityPolicy |
| architecture | string | `""` | Target CPU architecture for this workload. Empty imposes no constraint. `arm64` pins the pod to arm64 nodes, adding both the `kubernetes.io/arch` node selector and the toleration for the `kubernetes.io/arch=arm64:NoSchedule` taint that Giant Swarm arm64 node pools carry. Both are required, so this single value sets both. Requires a multi-arch container image; an amd64-only image will crash-loop with `exec format error` on an arm64 node. |
| nodeSelector | object | `{}` | Node selector for pod scheduling. Merged with `architecture`. Pinning to arm64 here rather than through `architecture` also adds the arm64 taint toleration, so either route is safe. A value that contradicts `architecture` fails the render. |
| tolerations | list | `[]` | Tolerations for pod scheduling. Merged with the toleration that `architecture: arm64` adds. |
