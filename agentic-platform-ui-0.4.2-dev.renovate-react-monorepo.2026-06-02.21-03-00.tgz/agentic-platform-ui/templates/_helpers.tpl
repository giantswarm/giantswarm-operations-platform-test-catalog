{{- /*
Validate slug at render time. Fail fast with a clear message rather than producing
a broken manifest that surfaces an error later in Flux reconcile.
*/ -}}

{{- define "agentic-platform-ui.validate" -}}
{{- $slug := .Values.slug | default "" -}}
{{- if not (regexMatch "^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$" $slug) -}}
{{- fail (printf "values.slug %q does not match ^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$" $slug) -}}
{{- end -}}
{{- end -}}

{{- /*
The release name. The Helm release is named externally (by the fleet HelmRelease),
but we provide a deterministic resource name here so that all resources within a
release agree on what to call the workload.
*/ -}}
{{- define "agentic-platform-ui.fullname" -}}
{{- printf "prototype-%s" .Values.slug | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "agentic-platform-ui.labels" -}}
app.kubernetes.io/name: agentic-platform-ui
app.kubernetes.io/instance: {{ include "agentic-platform-ui.fullname" . }}
app.kubernetes.io/managed-by: helm
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
agentic-platform-ui/slug: {{ .Values.slug | quote }}
{{- end -}}

{{- define "agentic-platform-ui.selectorLabels" -}}
app.kubernetes.io/name: agentic-platform-ui
app.kubernetes.io/instance: {{ include "agentic-platform-ui.fullname" . }}
{{- end -}}

{{- /*
Image reference. Registry and repo are hardcoded so that a compromised fleet bot
cannot redirect the deployment to an arbitrary image.

The image tag is derived from `.Chart.AppVersion`, not `.Chart.Version`. Flux's
source-controller appends the 12-char OCI artifact digest to `.Chart.Version`
as semver build metadata (e.g. `0.0.2+7fcf73b510eb`), which isn't a valid
Docker tag. AppVersion isn't touched by Flux. The architect orb stamps both
fields with the same gitsemver value at build time (since this repo has no
`pkg/project/project.go`), so chart and image co-version off AppVersion.

The `trimPrefix "0.0.0-"` accounts for future per-branch builds where the
chart is packaged as `0.0.0-branch-<slug>-<build-num>` but the image is
tagged `branch-<slug>-<build-num>` (registry tags aren't required to be semver).
*/ -}}
{{- define "agentic-platform-ui.image" -}}
gsociprivate.azurecr.io/giantswarm/agentic-platform-ui:{{ trimPrefix "0.0.0-" .Chart.AppVersion }}
{{- end -}}

{{- /*
SitePing feedback backend. A separate workload from the static-file app, named
`<fullname>-siteping`. Its `app.kubernetes.io/name` is deliberately distinct
(`agentic-platform-ui-siteping`) so the app Service/NetworkPolicy selectors —
which match `name=agentic-platform-ui` — never accidentally target these pods.
*/ -}}
{{- define "agentic-platform-ui.siteping.fullname" -}}
{{- printf "%s-siteping" (include "agentic-platform-ui.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "agentic-platform-ui.siteping.selectorLabels" -}}
app.kubernetes.io/name: agentic-platform-ui-siteping
app.kubernetes.io/instance: {{ include "agentic-platform-ui.fullname" . }}
{{- end -}}

{{- define "agentic-platform-ui.siteping.labels" -}}
{{ include "agentic-platform-ui.siteping.selectorLabels" . }}
app.kubernetes.io/managed-by: helm
app.kubernetes.io/component: siteping
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
agentic-platform-ui/slug: {{ .Values.slug | quote }}
{{- end -}}

{{- /*
SitePing backend image. Unlike the app image this lives in the PUBLIC
gsoci.azurecr.io registry (the backend contains nothing private), so the chart
pulls it without an imagePullSecret. Registry/repo are hardcoded for the same
supply-chain reason as the app image; the tag co-versions off AppVersion.
*/ -}}
{{- define "agentic-platform-ui.siteping.image" -}}
gsoci.azurecr.io/giantswarm/siteping-backend:{{ trimPrefix "0.0.0-" .Chart.AppVersion }}
{{- end -}}
